#%%
from surface2_functions import *
from Assignment_matrix import *
from Density_matrix import *
#%%
# state_prep_test(p_1q=0.003, 
#                 p_2q=0.02, 
#                 p_meas=0.02, 
#                 shots = 10000,
#                 T2 = 50,
# )

#%%
# Figure3(
#                 p_1q=0.002, 
#                 p_2q=0.02, 
#                 p_meas=0.01, 
#                 shots=10000,
#                 T2 = 15,
#                 squence_time = 2,)

#%%
# plot_figure5(   
#                 p_1q=0.002, 
#                 p_2q=0.02, 
#                 p_meas=0.01, 
#                 shots=1000000,
#                 T2 = 15,
#                 squence_time = 0,
#                 rounds=10,)

# %%
state = '+'
# density matrix 확인
den_mat = density_matrix(
    target_state = state,
                p_1q=0.002, 
                p_2q=0.02, 
                p_meas=0.01, 
                shots=10000,
                T2 = 15,
                squence_time = 2,
                )

# physical fidelity, probability, rho logical 확인
logical = {}
logical[0] = np.zeros(16)
logical[0][0b0000] = 1/np.sqrt(2)
logical[0][0b1111] = 1/np.sqrt(2)

logical[1] = np.zeros(16)
logical[1][0b0101] = 1/np.sqrt(2)
logical[1][0b1010] = 1/np.sqrt(2)
match state:
    case '0':
        psi = logical[0]
    case '1':
        psi = logical[1]
    case '+':
        psi = 1/np.sqrt(2)*(logical[0]+logical[1])
    case '-':
        psi = 1/np.sqrt(2)*(logical[0]-logical[1])

Logical_probability = logical[0].T @ den_mat @ logical[0] + logical[1].T @ den_mat @ logical[1]
rho_logical = np.zeros([2,2])

for i in range(2):
    for j in range(2):
        rho_logical[i][j] = logical[i].T @ den_mat @ logical[j] / Logical_probability

Phisical_Fidelity = psi.T @ den_mat @ psi
print(f"Phisical Fidelity Fphys : {Phisical_Fidelity:.3f}")
print(f"physical probability PL : {Logical_probability:.3f}")
print(rho_logical)